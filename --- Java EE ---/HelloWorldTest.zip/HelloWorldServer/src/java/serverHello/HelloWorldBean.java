/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverHello;

import javax.ejb.Stateless;

/**
 *
 * @author abate
 */
@Stateless
public class HelloWorldBean implements HelloWorldBeanRemote {

   // Add business logic below. (Right-click in editor and choose
   // "Insert Code > Add Business Method")
   
   public String sayHello(String name){
      return "Hello dear " + name + "!";
   }
   
}
