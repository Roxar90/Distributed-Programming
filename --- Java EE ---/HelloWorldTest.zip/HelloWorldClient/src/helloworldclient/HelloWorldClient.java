/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helloworldclient;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import serverHello.HelloWorldBeanRemote;

/**
 *
 * @author abate
 */
public class HelloWorldClient {

   public static void main(String[] args) throws NamingException {
      
      Context ctx = new InitialContext();
      
      HelloWorldBeanRemote remoteItem = (HelloWorldBeanRemote) ctx.lookup("java:global/HelloWorldServer/HelloWorldBean!serverHello.HelloWorldBeanRemote");
      System.out.println(remoteItem.sayHello("Abby"));
      
   }
   
}
