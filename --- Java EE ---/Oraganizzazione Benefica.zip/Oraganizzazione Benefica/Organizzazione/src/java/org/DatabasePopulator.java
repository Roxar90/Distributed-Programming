/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org;


import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

/**
 *
 * @author Rosario
 */
@Singleton
@Startup
@DataSourceDefinition(
        className = "org.apache.derby.jdbc.ClientDataSource",
        name="jdbc/EsameDS",
        databaseName = "EsameDB",
        user="APP",
        password = "APP",
        portNumber = 1527,
        serverName = "localhost"
        
    )
public class DatabasePopulator {
    
    @Inject
    private OrganizzazioneEJB ejb;
    private Organizzazione o1,o2,o3,o4;
    
    @PostConstruct
    public void populateDB(){
        o1 = new Organizzazione("1","Save the children Italia", "Roma", 291,53,408830,113169865,50f);
        o2 = new Organizzazione("2","Medici senza Frontiere", "Roma", 50,48,286004,61403682,50f);
        o3 = new Organizzazione("3","ActionAid", "Milano", 220,33,131920,68097472,100f);
        o4 = new Organizzazione("4","Emergency", "Milano", 50,7,66311,41842957,100f);
        
        ejb.createOrganizzazione(o1);
        ejb.createOrganizzazione(o2);
        ejb.createOrganizzazione(o3);
        ejb.createOrganizzazione(o4);
    }
    
    @PreDestroy
    public void destroyDB(){
        ejb.removeOrganizzazione(o1);        
        ejb.removeOrganizzazione(o2);        
        ejb.removeOrganizzazione(o3);
        ejb.removeOrganizzazione(o4);
    }
}
