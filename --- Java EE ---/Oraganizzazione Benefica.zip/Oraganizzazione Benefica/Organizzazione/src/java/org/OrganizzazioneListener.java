/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org;

import javax.enterprise.event.Observes;

/**
 *
 * @author Rosario
 */
public class OrganizzazioneListener {
    
    public void notify(@Observes Organizzazione o){
        System.out.println("E' stato aggiornato il numero di visitatori di : " + o.getNome()); 
    }
}
