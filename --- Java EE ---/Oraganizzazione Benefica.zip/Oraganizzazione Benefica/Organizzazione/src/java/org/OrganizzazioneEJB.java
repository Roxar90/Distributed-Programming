/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.inject.Inject;
import javax.jws.WebService;
import javax.persistence.EntityManager;

/**
 *
 * @author Rosario
 */
@Stateless
@LocalBean
@WebService
public class OrganizzazioneEJB implements OrganizzazioneEJBRemote {

    @Inject
    private EntityManager em;

    public OrganizzazioneEJB() {
    }

    
    
    @Override
    public void createOrganizzazione(Organizzazione o) {
        em.persist(o);
    }

    @Override
    public Organizzazione updateOrganizzazione(Organizzazione o) {
        return em.merge(o);
    }

    @Override
    public void removeOrganizzazione(Organizzazione o) {
        em.remove(em.merge(o));
    }

    @Override
    public Organizzazione getById(String Id) {
        return em.createNamedQuery(Organizzazione.FINDBYID, Organizzazione.class).setParameter(1, Id).getSingleResult();
    }

    @Override
    public List<Organizzazione> getByProgetti(int progetti) {
        return em.createNamedQuery(Organizzazione.FINDBYPROGETTI,Organizzazione.class).setParameter(1, progetti).getResultList();
    }

    @Override
    public List<Organizzazione> getAll() {
        return em.createNamedQuery(Organizzazione.FINDALL,Organizzazione.class).getResultList();
        
    }

    @Override @Counter
    public List<Organizzazione> getByBalance() {
        return em.createNamedQuery(Organizzazione.FINDBYBALANCE,Organizzazione.class).getResultList();
    }

    @Override
    public List<Organizzazione> getByTrasparency() {
        return em.createNamedQuery(Organizzazione.FINDBYTRASPARENCY,Organizzazione.class).getResultList();
    }

    
}
