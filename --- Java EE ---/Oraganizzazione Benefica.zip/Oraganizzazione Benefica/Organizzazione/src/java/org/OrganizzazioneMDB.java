/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org;

import javax.ejb.MessageDriven;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

/**
 *
 * @author Rosario
 */
@MessageDriven(mappedName = "jms/javaee7/Topic")
public class OrganizzazioneMDB implements MessageListener{

    @Inject
    private OrganizzazioneEJB ejb;
    @Inject
    private Event<Organizzazione> event;
    
    @Override
    public void onMessage(Message m) {
        try{
            String id = m.getStringProperty("id");
            Long donatori = m.getBody(Long.class);
            Organizzazione o = ejb.getById(id);
            o.setDonatori(donatori);
            ejb.updateOrganizzazione(o);
            event.fire(o);
        }catch(JMSException e){
            e.printStackTrace();
            System.out.println("Errore nell'aggiornamento dell'operazione");
        }
    }
    
}
