/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.XmlRootElement;
import static org.Organizzazione.FINDALL;
import static org.Organizzazione.FINDBYBALANCE;
import static org.Organizzazione.FINDBYID;
import static org.Organizzazione.FINDBYPROGETTI;
import static org.Organizzazione.FINDBYTRASPARENCY;

/**
 *
 * @author Rosario
 */
@XmlRootElement
@Entity
@NamedQueries( {
    @NamedQuery(name = FINDBYID, query="Select o from Organizzazione o where o.id= ?1"),
    @NamedQuery(name= FINDBYPROGETTI, query="Select o from Organizzazione o where o.progetti = ?1"),
    @NamedQuery(name= FINDALL, query="Select o from Organizzazione o"),
    @NamedQuery(name = FINDBYBALANCE, query="Select o from Organizzazione o where o.bilancio >50000000"),
    @NamedQuery(name = FINDBYTRASPARENCY, query="Select o from Organizzazione o where o.trasparenza = 100")
})
public class Organizzazione implements Serializable{
    
    public static final String FINDBYID = "Organizzazione.findbyId";
    public static final String FINDBYPROGETTI = "Organizzazione.findByProgetti";
    public static final String FINDALL = "Organizzazione.findAll";
    public static final String FINDBYBALANCE = "Organizzazione.findByBalance";
    public static final String FINDBYTRASPARENCY = "Organizzazione.findByTrasparency";
    
    @Id
    private String id;
    private String nome;
    private String sede;
    private int progetti;
    private int paesi;
    private long donatori;
    private double bilancio;
    private float trasparenza;
    
    public Organizzazione(){};

    public Organizzazione(String id, String nome, String sede, int progetti, int paesi, long donatori, double bilancio, float trasparenza) {
        this.id = id;
        this.nome = nome;
        this.sede = sede;
        this.progetti = progetti;
        this.paesi = paesi;
        this.donatori = donatori;
        this.bilancio = bilancio;
        this.trasparenza = trasparenza;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSede() {
        return sede;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }

    public int getProgetti() {
        return progetti;
    }

    public void setProgetti(int progetti) {
        this.progetti = progetti;
    }

    public int getPaesi() {
        return paesi;
    }

    public void setPaesi(int paesi) {
        this.paesi = paesi;
    }

    public long getDonatori() {
        return donatori;
    }

    public void setDonatori(long donatori) {
        this.donatori = donatori;
    }

    public double getBilancio() {
        return bilancio;
    }

    public void setBilancio(double bilancio) {
        this.bilancio = bilancio;
    }

    public float getTrasparenza() {
        return trasparenza;
    }

    public void setTrasparenza(float trasparenza) {
        this.trasparenza = trasparenza;
    }

    @Override
    public String toString() {
        return "Organizzazione{" + "id=" + id + ", nome=" + nome + ", sede=" + sede + ", progetti=" + progetti + ", paesi=" + paesi + ", donatori=" + donatori + ", bilancio=" + bilancio + ", trasparenza=" + trasparenza + '}';
    }
    
    
}
