/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org;

import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author Rosario
 */
@Remote
public interface OrganizzazioneEJBRemote {
    
    public void createOrganizzazione(Organizzazione o);
    public Organizzazione updateOrganizzazione(Organizzazione o);
    public void removeOrganizzazione(Organizzazione o);
    
    public Organizzazione getById(String Id);
    public List<Organizzazione> getByProgetti(int progetti);
    public List<Organizzazione> getAll();
    public List<Organizzazione> getByBalance();
    public List<Organizzazione> getByTrasparency();
    
}
