/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jmsclient;

import java.util.Scanner;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author Rosario
 */
public class JMSClient {

    
    public static void main(String[] args) throws NamingException {
        
        Context ctx = new InitialContext();
       
        ConnectionFactory factory = (ConnectionFactory) ctx.lookup("jms/javaee7/ConnectionFactory");
        Destination dest = (Destination) ctx.lookup("jms/javaee7/Topic");
        
        try(JMSContext context = factory.createContext()){
           Scanner in = new Scanner(System.in);
           System.out.println("Inserisci id: ");
           String id = in.nextLine();
           System.out.println("Inserisci nuovo numero di visitatori: ");
           Long visitatori = Long.parseLong(in.nextLine());
           
           context.createProducer().setProperty("id", id).send(dest,visitatori);
                   
        }
    }
    
}
