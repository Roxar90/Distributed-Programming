/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webclient;

import java.util.List;

/**
 *
 * @author Rosario
 */
public class WebClient {

    public static void main(String[] args) {
        List<org.Organizzazione> organizzazioni = getByTrasparency();
        for(org.Organizzazione o: organizzazioni)
            System.out.println("L'organizzazione : " + o.getNome() + " Ha il 100% di trasparenza");
    }

    public static java.util.List<org.Organizzazione> getByTrasparency() {
        org.OrganizzazioneEJBService serv = new org.OrganizzazioneEJBService();
        org.OrganizzazioneEJB port = serv.getOrganizzazioneEJBPort();
        return port.getByTrasparency();
    }
    
}
