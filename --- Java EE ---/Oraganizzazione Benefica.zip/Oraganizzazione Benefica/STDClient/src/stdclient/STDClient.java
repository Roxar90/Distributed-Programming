/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stdclient;

import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.Organizzazione;
import org.OrganizzazioneEJBRemote;

/**
 *
 * @author Rosario
 */
public class STDClient {

    
    public static void main(String[] args) throws NamingException {
       
        Context ctx = new InitialContext();
        
        OrganizzazioneEJBRemote ejb = (OrganizzazioneEJBRemote) ctx.lookup("java:global/Organizzazione/OrganizzazioneEJB!org.OrganizzazioneEJBRemote");
        List<Organizzazione> orgs = ejb.getAll();
        System.out.println("Organizzazioni presenti nel DB: ");
        for(Organizzazione o : orgs)
            System.out.println("Organizzazione : " + o);
        System.out.println("Organizzazioni con bilancio > di 50.000.000 : ");
        orgs = ejb.getByBalance();
         for(Organizzazione o : orgs)
            System.out.println(o);
    }
    
}
