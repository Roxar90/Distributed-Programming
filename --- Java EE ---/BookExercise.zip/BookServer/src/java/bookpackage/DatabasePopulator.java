/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookpackage;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

/**
 *
 * @author abate
 */

@Singleton
@Startup
@DataSourceDefinition(
   className = "org.apache.derby.jdbc.EmbeddedDataSource",
   name = "java:global/jdbc/chapter08DS",
   user = "app",
   password = "app",
   databaseName = "chapter08DB",
   properties = {"connectionAttributes=;create=true"}
)
public class DatabasePopulator {
   @Inject
   private BookEJB book_ejb;
   private Book firstBook, secondBook;
   @PostConstruct
   private void populateDB(){
      firstBook = new Book("My First Book", 35F, "My great first book", "ISBN", 600, true);
      secondBook = new Book("Another Book", 40.5F, "Another book to read", "ANOTHER_ISBN", 500, true);
      book_ejb.createBook(firstBook);
      book_ejb.createBook(secondBook);
   }
   @PreDestroy
   private void clearDatabase(){
      book_ejb.removeBook(firstBook);
      book_ejb.removeBook(secondBook);
   }
   
}
