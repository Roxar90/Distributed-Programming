/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookclient;

import bookpackage.BookEJBRemote;
import bookpackage.Book;
import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author abate
 */
public class BookClient {

   private static final String lookup_string = 
           "java:global/BookServer/BookEJB!bookpackage.BookEJBRemote";
   
   /**
    * @param args the command line arguments
    */
   public static void main(String[] args) throws NamingException {
      
      Context ctx = new InitialContext();
      BookEJBRemote myEjb = (BookEJBRemote) ctx.lookup(BookClient.lookup_string);
      
      Book myBook = new Book("Come superare PD", 12.5F, "Guida su come superare PD", "ISBM-BRTT", 400, false);
      myEjb.createBook(myBook);
      
      List<Book> listOfBooks = myEjb.findBooks();
      for (Book b : listOfBooks){
         System.out.println("---> " + b);
      }
      
      myBook.setTitle("Come non superare PD");
      listOfBooks = myEjb.findBooks();
      System.out.println("New output");
      for (Book b : listOfBooks){
         System.out.println("---> " + b);
      }
      
      myEjb.removeBook(myBook);
      listOfBooks = myEjb.findBooks();
      System.out.println("New output");
      for (Book b : listOfBooks){
         System.out.println("---> " + b);
      }
      
   }
   
}
