/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookpackage;

import static bookpackage.Book.FIND_ALL;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.validation.constraints.Size;

/**
 *
 * @author abate
 */
@Entity
@NamedQuery(name = FIND_ALL, query = "SELECT b FROM Book b")
public class Book implements Serializable {
   public static final String FIND_ALL = "Book.findAllBooks";
   @Id @GeneratedValue
   private Long id;
   @Column(nullable = false)
   private String title;
   private Float price;
   @Size(max = 2000)
   @Column(length = 2000)
   private String description;
   private String isbn;
   private Integer numberOfPages;
   private Boolean illustrations;
   
   public Book(){}
   
   public Book(String title, Float price, String description, String isbn, Integer numbOfPages, Boolean illustrations){
      this.title = title;
      this.price = price;
      this.description = description;
      this.isbn = isbn;
      this.numberOfPages = numbOfPages;
      this.illustrations = illustrations;
   }

   public String getTitle() {
      return title;
   }

   public void setTitle(String title) {
      this.title = title;
   }
   
   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public Float getPrice() {
      return price;
   }

   public void setPrice(Float price) {
      this.price = price;
   }

   public String getDescription() {
      return description;
   }

   public void setDescription(String description) {
      this.description = description;
   }

   public String getIsbn() {
      return isbn;
   }

   public void setIsbn(String isbn) {
      this.isbn = isbn;
   }

   public Integer getNumberOfPages() {
      return numberOfPages;
   }

   public void setNumberOfPages(Integer numberOfPages) {
      this.numberOfPages = numberOfPages;
   }

   public Boolean getIllustrations() {
      return illustrations;
   }

   public void setIllustrations(Boolean illustrations) {
      this.illustrations = illustrations;
   }
   
}
